@echo off
setlocal
pushd "%~dp0"
set "NFSUG_ROM_FILE=%~dp0Need for Speed - Underground (USA, Europe) (En,Fr,De,It).gba"
if not "%~1"=="" set "NFSUG_ROM_FILE=%~f1"
if not exist "%NFSUG_ROM_FILE%" (
 echo Place your own compatible GBA ROM beside this launcher,
 echo or drag your ROM file onto this launcher.
 pause
 popd
 exit /b 1
)
"%~dp0NFSUG-Source-Native-Preview.exe" --geometry-cache --rom "%NFSUG_ROM_FILE%" --report "%~dp0preview-session.json"
set "NFSUG_RUN_EXIT=%errorlevel%"
if not "%NFSUG_RUN_EXIT%"=="0" (
 echo Preview error. See preview-session.json here.
 pause
)
popd
exit /b %NFSUG_RUN_EXIT%
